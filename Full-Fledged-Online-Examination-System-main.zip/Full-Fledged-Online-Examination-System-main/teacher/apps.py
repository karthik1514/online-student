from django.apps import AppConfig


class TeacherConfig(AppConfig):
    name = 'teacher'
